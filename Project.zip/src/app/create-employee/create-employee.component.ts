import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Routes, ActivatedRoute } from '@angular/router'
import { Employee } from '../employee';
import { Location } from '@angular/common';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})

export class CreateEmployeeComponent implements OnInit {
  _id = this.route.snapshot.params['id'];
  empObj = {
    _id: this._id,
    first_name: '',
    last_name: '',
    title: '',
    department: '',
    email: '',
    gender: '',
    location: '',
    phone: '',
    branch: '',
    positionX: 250,
    positionY: 250,
  }
  newEmployee: boolean = false;
  employee: Employee
  constructor(private dataService: DataService, private route: ActivatedRoute, private location: Location) {
    let _id = this.route.snapshot.params['id'];
    if (_id == 'save') this.newEmployee = true;

    if (this.newEmployee == false) {
      this.employee = this.dataService.getEmployee(_id).subscribe((person) => {
        this.employee = person;
        console.log(person);
        this.empObj = person;
      });
    }
  }

  addEmployee() {
    this.dataService.addEmployee(this.empObj);
    console.log('Details of employee are: ', this.empObj)
  }
  modifyEmployee() {
    this.dataService.updateEmployee(this.empObj).subscribe(() => {
      console.log('Employee Updated');
    });
  }
  ngOnInit() {

  }
  goBack() {
    this.location.back();
  }
}
