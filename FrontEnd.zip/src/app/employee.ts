export class Employee {
    //_id: any;
    first_name: string;
    last_name: string;
    title: string;
    gender: string;
    department: string;
    email: string;
    location: string;
    phone: string;
    positionX: number;
    positionY: number;
}
